require 'color-schemer'
# require 'blend-mode'

# Set this to the root of your project when deployed:
# add_import_path '../stylesheets'
http_path = 'html'
css_dir = 'css'
sass_dir = 'sass'
