# Research

Links and inspiraiton

## General

- [Never use black](http://ianstormtaylor.com/design-tip-never-use-black/)


## Color Mixing

- [The Magical Tech Behind Paper For iPad's Color-Mixing Perfection](http://www.fastcompany.com/3002676/magical-tech-behind-paper-ipads-color-mixing-perfection)
- [Color scheme designer](http://colorschemedesigner.com/)

## Color Blindness

- [Why games need color blind modes – see SimCity with simulated color blindness](http://www.pcgamer.com/2013/02/01/why-games-need-color-blind-modes-see-simcity-with-simulated-color-blindness/)
- [Sim Daltonism app](http://michelf.ca/projects/sim-daltonism/)