require 'compass'
require 'compass-blend-modes'
Compass::Frameworks.register("color-schemer", :path => "#{File.dirname(__FILE__)}/..")

module ColorSchemer
  
  VERSION = "0.2.8"
  DATE = "2011-09-15"

end